"""SPEC §3.2 の型境界。

このモジュールは第1段の構造契約だけを定義する。エージェント側DTOは
oracle 由来情報へ型レベルで到達できないよう、OracleView/Feedback と分離する。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping

from abm.definition import (
    EmbedState,
    ExceptionAccumulator,
    FrequencyTable,
    MeritAccumulator,
    NamedDefinition,
)


class TargetType(str, Enum):
    ISOMORPHIC = "isomorphic"
    ANTI_ANALOGY = "anti_analogy"
    ROLE_REVERSAL = "role_reversal"
    ROLE_DIVERGENCE = "role_divergence"
    SURPLUS = "surplus"
    OPAQUE = "opaque"


class CorrectionMode(str, Enum):
    NONE = "none"
    CORRECTNESS_BIT = "correctness_bit"
    REVEALED_EDGE = "revealed_edge"


class SendingPolicy(str, Enum):
    RAW_INSTANCE_RANDOM = "raw_instance_random"


class RepairScope(str, Enum):
    FIRST_ORDER = "first_order"
    SECOND_ORDER = "second_order"
    ALL = "all"


class PredictionKind(str, Enum):
    EDGE_PREDICTION = "EdgePrediction"
    ABSTAIN = "Abstain"


@dataclass(frozen=True, slots=True)
class Entity:
    entity_id: str
    label: str | None = None
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "attributes", _freeze_mapping(self.attributes))

    def to_dict(self) -> dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "label": self.label,
            "attributes": dict(self.attributes),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Entity":
        return cls(
            entity_id=str(data["entity_id"]),
            label=data.get("label"),
            attributes=dict(data.get("attributes", {})),
        )


@dataclass(frozen=True, slots=True)
class Relation:
    relation_id: str
    predicate: str
    arguments: tuple[str, ...]
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "arguments", tuple(self.arguments))
        object.__setattr__(self, "attributes", _freeze_mapping(self.attributes))

    def to_dict(self) -> dict[str, Any]:
        return {
            "relation_id": self.relation_id,
            "predicate": self.predicate,
            "arguments": list(self.arguments),
            "attributes": dict(self.attributes),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Relation":
        return cls(
            relation_id=str(data["relation_id"]),
            predicate=str(data["predicate"]),
            arguments=tuple(str(v) for v in data.get("arguments", ())),
            attributes=dict(data.get("attributes", {})),
        )


@dataclass(frozen=True, slots=True)
class RelationGraph:
    graph_id: str
    entities: tuple[Entity, ...] = ()
    relations: tuple[Relation, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "entities", tuple(self.entities))
        object.__setattr__(self, "relations", tuple(self.relations))

    def to_dict(self) -> dict[str, Any]:
        return {
            "graph_id": self.graph_id,
            "entities": [entity.to_dict() for entity in self.entities],
            "relations": [relation.to_dict() for relation in self.relations],
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "RelationGraph":
        return cls(
            graph_id=str(data["graph_id"]),
            entities=tuple(Entity.from_dict(v) for v in data.get("entities", ())),
            relations=tuple(Relation.from_dict(v) for v in data.get("relations", ())),
        )


@dataclass(frozen=True, slots=True)
class AgentInput:
    base_graph: RelationGraph
    target_graph_partial: RelationGraph
    observable_mask: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "observable_mask", tuple(self.observable_mask))

    def to_dict(self) -> dict[str, Any]:
        return {
            "base_graph": self.base_graph.to_dict(),
            "target_graph_partial": self.target_graph_partial.to_dict(),
            "observable_mask": list(self.observable_mask),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AgentInput":
        return cls(
            base_graph=RelationGraph.from_dict(data["base_graph"]),
            target_graph_partial=RelationGraph.from_dict(data["target_graph_partial"]),
            observable_mask=tuple(str(v) for v in data.get("observable_mask", ())),
        )


@dataclass(frozen=True, slots=True)
class AgentConfig:
    threshold: float
    correction_mode: CorrectionMode
    lambda_: float = 1.0
    prototype_prior_weight: float = 0.0
    theta_prime: float = 0.0410
    tau_acc: float = 0.67
    nsim_threshold: float = 0.95
    alpha: float = 0.0
    beta: float = 0.0
    w: float = 0.0
    kappa: float = 1.0
    lambda_mix: float = 0.1
    abstain_charge: bool = False
    repair_scope: RepairScope = RepairScope.FIRST_ORDER
    verbatim_theta: float | None = None
    # 仕様 (E) 未決の主張。false のとき第二の経路は一切動かない（既存走行と bit 一致）。
    pending_claims: bool = False
    pending_gamma: float = 0.0
    pending_hold_cost: float = 0.0
    fill_selection: str = "most_frequent"
    # 局所頻度の指数（U-085 の v1）。0.0 のとき現行と厳密に一致する。
    local_lambda: float = 0.0
    # ★ 保持辺の候補に二階を入れるか（仮U-42・仮D-59）。世界の生成で使う旗で、
    #   エージェント自身は読まない。config の配線を一本化するために置く。
    holdout_include_second_order: bool = False
    # 識別に使う def(R) グラフ。"all" のとき墓石込み（2026-09-10 まで既定）。
    identification_graph: str = "live"
    # 自己点数の再利用。"legacy" のとき生存署名を鍵に再利用（2026-09-10 まで既定）。
    self_score_cache: str = "off"
    # 価格の意味論。"legacy" のとき関係IDへの参照も新規スロットと数える（既存走行と bit 一致）。
    pricing_rule: str = "legacy"
    # 補充（拡張）で墓石をどう選ぶか。
    # "legacy"        これまでの挙動。墓石の並び順にそのまま足す。
    #                 ★ 同じ slot の墓石が複数あると、同じ slot・同じ試行に二行が入る。
    #                 ★ 生存行のいる slot の古い墓石にも足すので、一つの位置に複数の生存行が同居する。
    # "one_per_slot"  ★ 案イ′（2026-09-22 決裁）。生存行のいない slot にだけ、同じ slot は一度だけ足す。
    #                 → SPEC_B1_impl_2026-08-28.md:313「位置は再利用され m_alloc は伸びない」と
    #                   :466-467 の m_live <= m_alloc を回復する。
    refill_rule: str = "legacy"
    # 充填で階数を揃えるときに使う、高階の述語の集合。
    # ★ 走行のたびに abm.seed.higher_order_predicates(seed) から作って渡す。
    #   None のまま充填に入ると fill_missing_slots が例外を出す（C-33 を避けるため黙って進まない）。
    higher_order_predicates: frozenset[str] | None = None

    def __post_init__(self) -> None:
        if self.identification_graph not in {"all", "live"}:
            raise ValueError(f"未知の identification_graph: {self.identification_graph}")
        if self.self_score_cache not in {"legacy", "off"}:
            raise ValueError(f"未知の self_score_cache: {self.self_score_cache}")
        if self.pricing_rule not in {"legacy", "spec"}:
            raise ValueError(f"未知の pricing_rule: {self.pricing_rule}")
        if self.refill_rule not in {"legacy", "one_per_slot"}:
            raise ValueError(f"未知の refill_rule: {self.refill_rule}")

    @property
    def verbatim_threshold(self) -> float:
        """逐語痕跡の削除閾値。未指定なら theta_prime に落ちる（後方互換）。"""
        return self.theta_prime if self.verbatim_theta is None else self.verbatim_theta


@dataclass(frozen=True, slots=True)
class VerbatimTrace:
    """単回露出した一場面と、その書込時刻。"""

    written_at: int
    scene: RelationGraph

    def sigma(self, now: int) -> float:
        elapsed = now - self.written_at
        return float("inf") if elapsed <= 0 else elapsed ** -0.5


@dataclass(frozen=True, slots=True)
class Prototype:
    """合成せずに保持する逐語場面の列。"""

    traces: tuple[VerbatimTrace, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "traces", tuple(self.traces))

    def alive(self, now: int, theta_prime: float) -> tuple[VerbatimTrace, ...]:
        return tuple(trace for trace in self.traces if trace.sigma(now) >= theta_prime)


@dataclass(frozen=True, slots=True)
class AgentState:
    prototype: Prototype = Prototype()
    public_history: tuple[Any, ...] = ()
    rng_state: str | int | tuple[Any, ...] | None = None
    definitions: Mapping[str, NamedDefinition] = field(default_factory=dict)
    merit: Mapping[tuple[str, int, int], MeritAccumulator] = field(default_factory=dict)
    embed: Mapping[tuple[str, int, int], EmbedState] = field(default_factory=dict)
    exceptions: Mapping[tuple[str, int], ExceptionAccumulator] = field(default_factory=dict)
    p_hat: FrequencyTable = FrequencyTable.empty()
    slot_history: Mapping[tuple[str, int], frozenset[str]] = field(default_factory=dict)
    # 仕様 (E) 未決の主張。要素は (述語, 引数の束縛, 持ち主の鍵)。
    # 引数の束縛は縛られていない位置を None（ワイルドカード）で表す。
    # ★ pending_claims=false のとき空のまま。_SNAPSHOT_OMIT_IF_EMPTY が正準形から省く。
    pending_claims: tuple[Any, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "public_history", tuple(self.public_history))
        object.__setattr__(self, "pending_claims", tuple(self.pending_claims))


@dataclass(frozen=True, slots=True)
class EdgePrediction:
    edge: Relation


@dataclass(frozen=True, slots=True)
class Abstain:
    reason: str | None = None


Prediction = EdgePrediction | Abstain


@dataclass(frozen=True, slots=True)
class AgentOutput:
    prediction: Prediction
    trace: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "trace", _freeze_mapping(self.trace))


@dataclass(frozen=True, slots=True)
class OracleView:
    G_star: RelationGraph
    held_out_edge: Relation
    target_type: TargetType
    seed_id: str


@dataclass(frozen=True, slots=True)
class ScoringKey:
    held_out_edge: Relation


@dataclass(frozen=True, slots=True)
class CorrectnessBit:
    is_correct: bool


@dataclass(frozen=True, slots=True)
class RevealedEdge:
    edge: Relation


Feedback = None | CorrectnessBit | RevealedEdge


def _freeze_mapping(data: Mapping[str, Any]) -> Mapping[str, Any]:
    return MappingProxyType(dict(data))
