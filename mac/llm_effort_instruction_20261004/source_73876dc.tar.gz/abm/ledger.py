"""SPEC B0+B2 §B.9 の書き込み専用 JSONL 台帳。"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import subprocess
from typing import Any, Mapping

from abm.logging_schema import LOGGING_SCHEMA_FIELDS


D23_FIELDS = (
    "coin_t", "f_realized", "f_fired", "feedback_content", "held_out_content",
    "expansion_and_filling_all", "constituent_reason_123", "type2_fired",
    "predictions_all_slots", "oracle_verdict", "registration_event", "deletion_event",
    "deletion_ell", "tie_event", "dangling_ref_onset", "dangling_ref_duration", "R_used",
    # 仕様 (E) 未決の主張。毎試行記録する（§3-3）。
    "pending_claims_open", "pending_claims_new",
    "pending_claims_confirmed", "pending_merit_awarded",
    "def_R_diff", "agent_state_snapshot_hash", "state_snapshot", "transmission_event", "scene_G_star_ref",
)
MECHANISM_FIELDS = (
    "m_alloc", "m_live", "theta_prime", "tau", "constituent_states", "entity_map_covered",
    "slot_history_size", "filled_predicate", "slot_signature", "support_at_adoption",
    "charge_source", "verbatim_written", "reg_del_events", "exception_bits_charged",
    "M051_balance", "matcher", "abstain_reason", "n_tie_candidates", "candidate_distribution",
    "enumeration_version", "V_vocab", "merit_event_times", "outcome_category", "tau_passed_defs",
    # 予測がどの経路から出たか（2026-09-12 追加）。
    #   projection / filling_live / filling_tombstone / null（棄権）
    "prediction_path",
    # 階数の制約で候補が空になり、埋まらなかったスロット数（2026-09-12 追加）。
    "filling_empty_pool_slots",
)
RESEARCH_FIELDS = (
    "p1", "p0", "Sel", "OA", "f_realized",
    "verbatim_baseline_prediction", "verbatim_baseline_hit", "counterfactual_predictions",
)
ARM_DESCRIPTOR_FIELDS = (
    "arm_alpha", "arm_beta", "arm_w", "arm_kappa", "arm_repair_scope",
    "arm_verbatim_theta", "arm_fill_selection",
    "arm_holdout_repr", "arm_f_profile",
    "arm_lambda_mix", "arm_abstain_charge", "arm_temperature", "arm_d_shared",
    "arm_adaptation_table",
    "arm_identification_graph", "arm_self_score_cache",
    "arm_pricing_rule",
    "arm_refill_rule",
    "arm_local_lambda",
    "arm_holdout_second_order",
)
NON_NULL_FIELDS = frozenset(
    ("exception_bits_charged", "constituent_reason_123", "oracle_verdict", "m_live", "support_at_adoption")
)


def _unique_fields(*groups: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(field for group in groups for field in group))


LEDGER_FIELDS = _unique_fields(
    LOGGING_SCHEMA_FIELDS, D23_FIELDS, MECHANISM_FIELDS, RESEARCH_FIELDS
)
if len(LOGGING_SCHEMA_FIELDS) != 38:
    raise RuntimeError(f"層A台帳欄は38本ではない: {len(LOGGING_SCHEMA_FIELDS)}")
if len(LEDGER_FIELDS) != 95:
    raise RuntimeError(
        "台帳欄は95本ではない: "
        f"A={len(LOGGING_SCHEMA_FIELDS)}, D23={len(D23_FIELDS)}, "
        f"mechanism={len(MECHANISM_FIELDS)}, "
        f"research={len(RESEARCH_FIELDS)}, unique={len(LEDGER_FIELDS)}"
    )
# ★ 2026-09-22  arm_refill_rule（案イ′ の旗）を足したので 19 → 20。
if len(ARM_DESCRIPTOR_FIELDS) != 20:
    raise RuntimeError(f"腕記述子は20本ではない: {len(ARM_DESCRIPTOR_FIELDS)}")


@dataclass(frozen=True, slots=True)
class RunHeader:
    arm_alpha: float
    arm_beta: float
    arm_w: float
    arm_kappa: float
    arm_repair_scope: str
    arm_holdout_repr: str
    arm_f_profile: str
    arm_lambda_mix: float
    arm_abstain_charge: bool
    arm_temperature: float | None
    arm_d_shared: float | None
    arm_adaptation_table: str | None
    run_seed: str | int
    trial_count: int
    agent_ids: tuple[str, ...]
    seed_file_sha256: str
    world_hash: str
    code_commit: str
    theta_prime: float
    tau_acc: float
    f_setting: float | str
    arm_verbatim_theta: float | None = None
    arm_fill_selection: str = "most_frequent"
    arm_identification_graph: str = "all"
    arm_self_score_cache: str = "legacy"
    arm_pricing_rule: str = "legacy"
    arm_refill_rule: str = "legacy"
    arm_local_lambda: float = 0.0
    arm_holdout_second_order: bool = False

    def to_dict(self) -> dict[str, Any]:
        # ★ local_lambda = 0.0（現行の挙動）のときは欄を書かない。
        #   既存 走行の台帳とヘッダをバイト一致させるため（段2 門a）。
        fields = (*ARM_DESCRIPTOR_FIELDS, *RUN_INPUT_FIELDS)
        # ★ 既定値（現行の挙動）の欄は書かない。既存台帳とヘッダをバイト一致させるため。
        omit = {"arm_local_lambda": 0.0, "arm_holdout_second_order": False,
                "arm_refill_rule": "legacy"}
        return {field: getattr(self, field) for field in fields
                if not (field in omit and getattr(self, field) == omit[field])}


RUN_INPUT_FIELDS = (
    "run_seed", "trial_count", "agent_ids", "seed_file_sha256", "world_hash",
    "code_commit", "theta_prime", "tau_acc", "f_setting",
)


def _code_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return "unknown"


class Ledger:
    """新規台帳を作り、runヘッダと試行行を同期追記する。"""

    def __init__(self, path: str | Path, header: RunHeader, *, compress: bool = False) -> None:
        self._path = Path(path)
        self._compress = compress
        if compress:
            import gzip
            self._stream = gzip.open(self._path, "xt", encoding="utf-8", compresslevel=6)
        else:
            self._stream = self._path.open("x", encoding="utf-8")
        self._write_line({"record_type": "run_header", **header.to_dict()})

    def append(self, record: Mapping[str, Any]) -> None:
        keys = frozenset(record)
        expected = frozenset(LEDGER_FIELDS)
        if keys != expected:
            missing = sorted(expected - keys)
            extra = sorted(keys - expected)
            raise ValueError(f"台帳欄が不一致: missing={missing}, extra={extra}")
        null_fields = sorted(field for field in NON_NULL_FIELDS if record[field] is None)
        if null_fields:
            raise ValueError(f"毎試行 non-null 欄が null: {null_fields}")
        self._write_line({"record_type": "trial", **record})

    def close(self) -> None:
        if not self._stream.closed:
            self._stream.close()

    def __enter__(self) -> "Ledger":
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        self.close()

    def _write_line(self, value: Mapping[str, Any]) -> None:
        self._stream.write(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
        self._stream.flush()
        if not self._compress:
            os.fsync(self._stream.fileno())


def empty_record(**values: Any) -> dict[str, Any]:
    """B1未実装欄を null で立て、与えられた同期値を入れる。"""

    unknown = sorted(set(values) - set(LEDGER_FIELDS))
    if unknown:
        raise ValueError(f"未知の台帳欄: {unknown}")
    return {field: values.get(field) for field in LEDGER_FIELDS}
