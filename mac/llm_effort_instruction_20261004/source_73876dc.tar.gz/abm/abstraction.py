"""SPEC B1 §C.6.2 のm1（登録と更新）。"""

from __future__ import annotations

from dataclasses import replace
from hashlib import sha256
from abm.accounting import freeze_price, initial_merit
from abm.definition import Constituent, EmbedState, ExceptionAccumulator, NamedDefinition
from abm.domains import AgentState, Relation, RelationGraph
from abm.filling import _mapped_arguments, observe_slot
from abm.sme import Alignment, map_graphs


def _identify_definition(
    state: AgentState,
    scene: RelationGraph,
    threshold: float,
    self_score_cache: dict[str, float] | None = None,
    *,
    identification_graph: str = "all",
    self_score_cache_mode: str = "legacy",
) -> str | None:
    """SEQL/GEL の NSIM 閾値を最初に満たす生存 def(R) を同定する。"""

    if identification_graph not in {"all", "live"}:
        raise ValueError(f"未知の identification_graph: {identification_graph}")
    if self_score_cache_mode not in {"legacy", "off"}:
        raise ValueError(f"未知の self_score_cache: {self_score_cache_mode}")
    cache = self_score_cache if self_score_cache is not None else {}
    definitions = sorted(
        (definition for definition in state.definitions.values() if definition.m_live > 0),
        key=lambda definition: (-definition.assimilation_count, -definition.registered_at),
    )
    for definition in definitions:
        graph = _definition_graph(definition, mode=identification_graph)
        if self_score_cache_mode == "off":
            # ★ 渡された辞書は読まず書かず、毎回 map_graphs で計算する。
            self_score = map_graphs(graph, graph).alignment.total_score
        else:
            live_signature = tuple(
                (row.slot_index, row.registered_at)
                for row in definition.constituents
                if row.alive
            )
            cache_key = repr((definition.name, live_signature))
            self_score = cache.get(cache_key)
            if self_score is None:
                self_score = map_graphs(graph, graph).alignment.total_score
                cache[cache_key] = self_score
        if self_score <= 0:
            continue
        score = map_graphs(graph, scene).alignment.total_score
        if score / self_score >= threshold:
            return definition.name
    return None


def m1(
    state: AgentState,
    base: RelationGraph,
    target: RelationGraph,
    alignment: Alignment,
    trial: int,
    *,
    name: str | None = None,
    base_written_at: int,
    horizon: int,
    pricing_rule: str = "legacy",
    refill_rule: str = "legacy",
    local_lambda: float = 0.0,
) -> tuple[AgentState, dict[str, object] | None]:
    """整列の共通部分からサイズ2以上の def(R) を登録・更新する。"""

    base_by_id = {relation.relation_id: relation for relation in base.relations}
    target_by_id = {relation.relation_id: relation for relation in target.relations}
    raw_pairs = [
        (base_by_id[left], target_by_id[right])
        for left, right in sorted(alignment.relation_mapping.items())
        if left in base_by_id and right in target_by_id
    ]
    structural_ids = _structural_relation_ids(base)
    pairs = [
        pair for pair in raw_pairs
        if pair[0].relation_id in structural_ids and pair[0].predicate == pair[1].predicate
    ]
    if len(pairs) < 2:
        return state, None
    definition_name = name or _definition_name(pairs)
    old = state.definitions.get(definition_name)
    if old is None:
        common_relations = tuple(left for left, _ in pairs)
        constituents = tuple(
            _constituent(index, trial, left, common_relations, state, len(pairs),
                         pricing_rule=pricing_rule)
            for index, (left, _) in enumerate(pairs)
        )
        definition = NamedDefinition(definition_name, constituents, len(constituents), trial)
    else:
        definition = _extend_definition(old, pairs, state, trial,
                                        pricing_rule=pricing_rule, base=base,
                                        refill_rule=refill_rule)
        definition = replace(
            definition,
            assimilation_count=old.assimilation_count + 1,
        )

    definitions = dict(state.definitions)
    definitions[definition_name] = definition
    merit = dict(state.merit)
    embed = dict(state.embed)
    exceptions = dict(state.exceptions)
    history = dict(state.slot_history)
    for constituent in definition.constituents:
        key = (definition_name, constituent.slot_index, constituent.registered_at)
        exception_key = (definition_name, constituent.slot_index)
        if constituent.registered_at == trial:
            merit[key] = initial_merit(
                constituent.slot_index, trial, trial - base_written_at, horizon
            )
            embed[key] = EmbedState(constituent.slot_index, 0.0, 0.0)
            exceptions[exception_key] = ExceptionAccumulator((0.0,) * 16, 0.0, 0)
    # slot_history は充足した述語だけでなく、def(R) の各位置に実際に観測された
    # 述語を持つ。位置は §C.5.2b と同じ写像済み引数タプルで同定する。
    # ★ 履歴観測は墓石込みで据え置く。識別の identification_graph を持ち込まない。
    definition_alignment = map_graphs(
        _definition_graph(definition, mode="all"), target
    ).alignment
    for constituent in definition.constituents:
        position = _mapped_arguments(
            constituent.relation,
            definition_alignment.entity_mapping,
            definition_alignment.relation_mapping,
        )
        if position is None:
            continue
        for observed in target.relations:
            if observed.arguments == position:
                history = observe_slot(
                    history,
                    definition_name,
                    constituent.slot_index,
                    observed.predicate,
                    local_lambda,
                )
    event_id = _alignment_event_id(alignment)
    next_state = replace(
        state, definitions=definitions, merit=merit, embed=embed,
        exceptions=exceptions, slot_history=history,
    )
    relation_ids = {row.relation.relation_id for row in definition.constituents}
    return next_state, {
        "kind": "registration",
        "R": definition_name,
        # ★★ 計装2（2026-09-20）  名前の出どころ。★ nsim ＝ 経路A ／ hash ＝ 経路B。
        #   ★ loop.py:112 が渡す name が NSIM の返り値（_identify_definition）。
        "name_source": "nsim" if name else "hash",
        "was_extension": old is not None,
        # ★ 計装5  定義の変更版 ID。★ assimilation_count は m1 が触るたびに増える。
        "definition_version": definition.assimilation_count,
        "alignment_event_id": event_id,
        "trial": trial,
        "base_written_at": base_written_at,
        "constituents": [{
            # ★ 計装4  構成素の一意 ID。★ SPEC_B1:312 の同一性 (slot_index, registered_at) に R を足した三つ組。
            "uid": f"{definition_name}#{row.slot_index}#{row.registered_at}",
            "slot_index": row.slot_index, "registered_at": row.registered_at,
            "predicate": row.relation.predicate, "arity": len(row.relation.arguments),
            "arguments": list(row.relation.arguments),
            "arg_kinds": ["relation" if argument in relation_ids else "entity" for argument in row.relation.arguments],
            "alive": row.alive,
        } for row in definition.constituents],
        "m_alloc": definition.m_alloc,
        "m_live": definition.m_live,
    }


def _constituent(
    index: int,
    trial: int,
    relation: Relation,
    relations: tuple[Relation, ...],
    state: AgentState,
    m_alloc: int,
    *,
    pricing_rule: str = "legacy",
) -> Constituent:
    new_slots = _new_slot_count(relation, relations, pricing_rule=pricing_rule)
    price = freeze_price(state.p_hat, relation, new_slots, m_alloc)
    return Constituent(index, trial, relation, price)


def _extend_definition(
    old: NamedDefinition,
    pairs: list[tuple[Relation, Relation]],
    state: AgentState,
    trial: int,
    *,
    pricing_rule: str = "legacy",
    base: RelationGraph | None = None,
    refill_rule: str = "legacy",
) -> NamedDefinition:
    existing = {constituent.relation.predicate for constituent in old.constituents if constituent.alive}
    additions = [left for left, _ in pairs if left.predicate not in existing]
    tombstones = [row for row in old.constituents if not row.alive]
    if refill_rule == "one_per_slot":
        # ★ 案イ′（2026-09-22 決裁）。生存行のいない slot にだけ、同じ slot は一度だけ足す。
        #   ★ 並び順は old.constituents の順のまま（新しい規則を足さない）。
        #   ★ あふれた行は足さない（m_alloc は伸ばさない。SPEC_B1_impl:313）。
        occupied = {row.slot_index for row in old.constituents if row.alive}
        seen: set[int] = set()
        picked = []
        for row in tombstones:
            if row.slot_index in occupied or row.slot_index in seen:
                continue
            seen.add(row.slot_index)
            picked.append(row)
        tombstones = picked
    if not additions or not tombstones:
        return old
    rows = list(old.constituents)
    # ★ 新規スロット数の比較集合は def(R) 全体である（SPEC_B1_impl_2026-08-28.md:310 と
    #   :1387「`turn(b,c)` の `c` が def(M4) の中でこの行にしか現れないため」）。
    #   今回足す行だけを見ると、既に定義にある行への参照が新規スロットに数えられ、
    #   「既にあるほど価格が不利になる」逆向きになる。生存構成素を比較集合に入れる。
    #   ★ 墓石は入れない。
    scope = tuple(additions) + tuple(
        constituent.relation for constituent in old.constituents if constituent.alive
    )
    predicate_of = (
        {item.relation_id: item.predicate for item in base.relations}
        if base is not None else None
    )
    for relation, tombstone in zip(additions, tombstones):
        price = freeze_price(
            state.p_hat,
            relation,
            _new_slot_count(relation, scope, pricing_rule=pricing_rule,
                            predicate_of=predicate_of),
            old.m_alloc,
        )
        rows.append(Constituent(tombstone.slot_index, trial, relation, price))
    return NamedDefinition(
        old.name,
        tuple(rows),
        old.m_alloc,
        old.registered_at,
        old.assimilation_count,
    )


def _new_slot_count(
    relation: Relation,
    relations: tuple[Relation, ...],
    *,
    pricing_rule: str = "legacy",
    predicate_of: dict[str, str] | None = None,
) -> int:
    skip: set[str] = set()
    if pricing_rule == "spec":
        # ★ 比較集合の中に実体として存在する行への参照は、新規スロットではない
        skip = {item.relation_id for item in relations}
        if predicate_of is not None:
            # ★ 比較集合に別の場面から来た行（定義の生存構成素）が混ざるとき、
            #   関係IDは場面ごとに作られる（abm/world.py:39-41 opaque_id に trial_index が入る）
            #   ので ID では照合できない。述語で照合する。
            #   引数が実体のときは predicate_of に無いので、扱いは変わらない。
            scope = {item.predicate for item in relations}
            skip |= {
                relation_id for relation_id, predicate in predicate_of.items()
                if predicate in scope
            }
    return sum(
        1 for argument in relation.arguments
        if argument not in skip
        and sum(argument in item.arguments for item in relations) == 1
    )


def _definition_name(pairs: list[tuple[Relation, Relation]]) -> str:
    material = "\x1f".join(sorted(left.predicate for left, _ in pairs)).encode()
    return f"R_{sha256(material).hexdigest()[:16]}"


def _alignment_event_id(alignment: Alignment) -> str:
    material = repr(sorted(alignment.relation_mapping.items())).encode()
    return sha256(material).hexdigest()[:16]


def _structural_relation_ids(graph: RelationGraph) -> frozenset[str]:
    relation_ids = {relation.relation_id for relation in graph.relations}
    higher_order = {
        relation.relation_id
        for relation in graph.relations
        if any(argument in relation_ids for argument in relation.arguments)
    }
    referenced = {
        argument
        for relation in graph.relations
        if relation.relation_id in higher_order
        for argument in relation.arguments
        if argument in relation_ids
    }
    return frozenset(higher_order | referenced)


def _definition_graph(definition: NamedDefinition, *, mode: str = "all") -> RelationGraph:
    """def(R) を SME 入力グラフへ変換する。

    mode="all"   墓石を含む全構成素を関係として並べる（既定。履歴観測はこちら）。
    mode="live"  関係だけを row.alive で絞る。relation_ids と entities は
                 墓石を含む全構成素から作る。agent_runtime._definition_graph と同じ規則。
    """

    if mode not in {"all", "live"}:
        raise ValueError(f"未知の identification_graph: {mode}")
    relation_ids = {row.relation.relation_id for row in definition.constituents}
    entity_ids = sorted({
        argument
        for row in definition.constituents
        for argument in row.relation.arguments
        if argument not in relation_ids
    })
    from abm.domains import Entity

    return RelationGraph(
        graph_id=f"definition:{definition.name}",
        entities=tuple(Entity(entity_id) for entity_id in entity_ids),
        relations=tuple(
            row.relation for row in definition.constituents
            if mode == "all" or row.alive
        ),
    )
