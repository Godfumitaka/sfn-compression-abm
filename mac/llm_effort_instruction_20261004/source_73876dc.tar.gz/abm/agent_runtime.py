"""BUILD ORDER 第2段のエージェント実行境界。

このモジュールは SPEC §3.2 の二フェーズ契約だけを実装する。
`redact` は信頼済み境界として完全グラフを読むが、`predict` は redaction 後の
`AgentInput`・凍結状態・設定・RNG だけを受け取り、oracle 由来値を受け取らない。
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from random import Random
from typing import Any, Iterable, Mapping, Protocol, TypeAlias

from abm.domains import (
    Abstain,
    AgentConfig,
    AgentInput,
    AgentOutput,
    AgentState,
    CorrectnessBit,
    EdgePrediction,
    Feedback,
    Relation,
    RelationGraph,
    RevealedEdge,
    Prototype,
    VerbatimTrace,
)
from abm.filling import fill_missing_slots
from abm.accounting import update_frequency
from abm.sme import apply_threshold, map_graphs, project


class RNG(Protocol):
    """`predict` に注入できる最小乱数インターフェース。"""

    def random(self) -> float: ...


FrozenAgentState: TypeAlias = AgentState


@dataclass(frozen=True, slots=True)
class PendingState:
    """予測確定後、フィードバック受領前の保留状態。

    oracle 由来のフィードバックはここには含めず、`update` の引数としてだけ受ける。
    """

    previous_state: FrozenAgentState
    output: AgentOutput
    agent_input: AgentInput | None = None
    rng_state: str | int | tuple[Any, ...] | None = None
    # ★ 記録専用（D23）。投影が出した候補を、一本に絞る前に控える。
    #   trace には入れない。trace は public_history 経由で状態ハッシュに入るため。
    projected_edge: Any = None
    filling_slot_history_size: int = 0
    filling_n_tie_candidates: int = 0
    filling_candidate_distribution: tuple[dict[str, object], ...] = ()
    # ★ 記録専用。予測がどの経路から出たか。
    #   projection / filling_live / filling_tombstone / None（棄権）
    prediction_path: str | None = None
    # ★ 記録専用。階数の制約で候補が空になり埋まらなかったスロット数。
    filling_empty_pool_slots: int = 0


def predict(
    agent_input: AgentInput,
    state: FrozenAgentState,
    config: AgentConfig,
    rng: RNG,
) -> tuple[AgentOutput, PendingState]:
    """公開入力と不変状態だけから P1〜P7 を実行する。"""

    if not state.prototype.traces:
        output = AgentOutput(prediction=Abstain(reason="no_prototype"), trace={"tau_passed_defs": []})
        return output, PendingState(state, output, agent_input, _snapshot_rng_state(rng, state.rng_state))
    ranked = []
    for trace in state.prototype.traces:
        result = map_graphs(trace.scene, agent_input.target_graph_partial)
        ranked.append((result, trace))
    mapping, selected_trace = sorted(
        ranked,
        key=lambda item: (-item[0].alignment.total_score, -item[1].written_at, item[1].scene.graph_id),
    )[0]
    base = selected_trace.scene
    threshold = apply_threshold(mapping, config.threshold)
    trace: dict[str, Any] = {
        "alignment": mapping.alignment,
        "support_at_adoption": 0,
        "R_used": None,
        "m_live": 0,
        "filled_slots": (),
        "entity_map_covered": False,
        "selected_scene": base,
        "selected_scene_written_at": selected_trace.written_at,
        "tau_passed_defs": [],
    }
    projected_edge = None          # ★ 記録専用（D23）。振る舞いには使わない
    prediction_path: str | None = None   # ★ 記録専用。振る舞いには使わない
    filling = None
    if not threshold.accepted:
        prediction = Abstain(reason="below_threshold")
    else:
        if not state.definitions:
            prediction = Abstain(reason="no_definition")
        else:
            selected = _select_definition(state, agent_input.target_graph_partial, config)
            if selected is None:
                prediction = Abstain(reason="no_definition")
            else:
                _, support, definition, graph, definition_alignment, tie_event, passed = selected
                trace["tau_passed_defs"] = passed
                name = definition.name
                trace["support_at_adoption"] = support
                trace["m_live"] = definition.m_live
                trace["definition_alignment"] = definition_alignment
                trace["tie_event"] = tie_event
                if support >= min(2, definition.m_live):
                    trace["R_identified"] = name
                if support < _need(config.tau_acc, definition.m_live):
                    prediction = Abstain(reason="below_tau")
                else:
                    trace["R_used"] = name
                    prediction = project(
                        definition_alignment,
                        graph,
                        agent_input.target_graph_partial,
                        prototype_prior_weight=0.0,
                    )
                    # ★ 記録専用（D23）。下で一本に絞る前の投影候補を控える。
                    #   ambiguous_projection の棄権でも候補を失わないため、ここで取る。
                    if isinstance(prediction, EdgePrediction):
                        projected_edge = prediction.edge
                    filling = fill_missing_slots(
                        definition,
                        agent_input.target_graph_partial,
                        definition_alignment.entity_mapping,
                        definition_alignment.relation_mapping,
                        state.slot_history,
                        state.p_hat,
                        config.fill_selection,
                        rng,
                        higher_order_predicates=config.higher_order_predicates,
                        local_lambda=config.local_lambda,
                    )
                    trace.update(
                        filled_slots=filling.relations,
                        filled_slot_indices=filling.slot_indices,
                        filling_fallback=filling.used_fallback,
                        entity_map_covered=all(
                            argument in definition_alignment.entity_mapping
                            or argument in definition_alignment.relation_mapping
                            for row in definition.constituents
                            for argument in row.relation.arguments
                        ),
                    )
                    if filling.ambiguous:
                        prediction = Abstain(reason="ambiguous_projection")
                    elif isinstance(prediction, Abstain) and filling.relations:
                        prediction = EdgePrediction(filling.relations[0])
                        # ★ 記録専用。埋めた行の構成素が生きていたか墓石だったか。
                        alive = filling.alive_by_slot[0] if filling.alive_by_slot else None
                        prediction_path = (
                            "filling_live" if alive else "filling_tombstone"
                        )
                    elif isinstance(prediction, Abstain):
                        prediction = Abstain(reason="no_projectable_relation")
                    elif isinstance(prediction, EdgePrediction):
                        prediction_path = "projection"
    output = AgentOutput(prediction=prediction, trace=trace)
    pending = PendingState(
        previous_state=state,
        output=output,
        agent_input=agent_input,
        rng_state=_snapshot_rng_state(rng, state.rng_state),
        projected_edge=projected_edge,
        prediction_path=prediction_path,
        filling_empty_pool_slots=filling.empty_pool_slots if filling is not None else 0,
        filling_slot_history_size=filling.slot_history_size if filling is not None else 0,
        filling_n_tie_candidates=filling.n_tie_candidates if filling is not None else 0,
        filling_candidate_distribution=(
            filling.candidate_distribution if filling is not None else ()
        ),
    )
    return output, pending


def _need(tau_acc: float, m_live: int) -> int:
    """採択に必要な支持数。

    tau_acc >= 1.0 のとき「絶対数読み」に切り替える。
      tau_acc = 1.0 + k  →  未一致 k 本まで許す  →  必要支持数 = m_live - k
    それ未満は従来どおり比読み ceil(tau_acc * m_live)。
    """
    from math import ceil

    if tau_acc >= 1.0:
        k = int(round(tau_acc - 1.0))
        return max(m_live - k, 1)
    return ceil(tau_acc * m_live)


def _select_definition(
    state: AgentState,
    scene: RelationGraph,
    config: AgentConfig,
) -> tuple[float, int, Any, RelationGraph, Any, bool, list[dict[str, Any]]] | None:
    """各 def(R) を場面に当て、支持比が最大のものを返す。"""

    # def(R) の採択に絶対 threshold は適用しない。
    ranked = []
    for definition in state.definitions.values():
        if definition.m_live == 0:
            continue
        graph = _definition_graph(definition)
        alignment = map_graphs(graph, scene).alignment
        if alignment is None:
            continue
        support = sum(
            1 for constituent in definition.constituents
            if constituent.alive
            and constituent.relation.relation_id in alignment.relation_mapping
        )
        ranked.append((support / definition.m_live, support, definition, graph, alignment))
    if not ranked:
        return None
    ranked.sort(
        key=lambda item: (-item[0], -item[2].m_live, -item[2].registered_at, item[2].name)
    )
    best = ranked[0]
    tie_event = sum(
        item[0] == best[0]
        and item[2].m_live == best[2].m_live
        and item[2].registered_at == best[2].registered_at
        for item in ranked
    ) > 1
    best_name = best[2].name
    passed = [{"R": definition.name, "support": support, "m_live": definition.m_live,
               "ratio": ratio, "selected": definition.name == best_name}
              for ratio, support, definition, _graph, _alignment in ranked
              if support >= _need(config.tau_acc, definition.m_live)]
    return (*best, tie_event, passed)


def _definition_graph(definition: Any) -> RelationGraph:
    relation_ids = {row.relation.relation_id for row in definition.constituents}
    entity_ids = sorted({
        argument
        for row in definition.constituents
        for argument in row.relation.arguments
        if argument not in relation_ids
    })
    from abm.domains import Entity

    return RelationGraph(
        graph_id=f"definition:{definition.name}",
        entities=tuple(Entity(entity_id) for entity_id in entity_ids),
        relations=tuple(row.relation for row in definition.constituents if row.alive),
    )


def update(pending: PendingState, feedback: Feedback) -> AgentState:
    """保留状態と予測後フィードバックだけから次の `AgentState` を返す。"""

    state = pending.previous_state
    written = pending.agent_input.target_graph_partial if pending.agent_input is not None else None
    history = (*state.public_history, pending.output)
    p_hat = update_frequency(state.p_hat, written.relations if written is not None else ())
    trial = max((trace.written_at for trace in state.prototype.traces), default=-1) + 1
    prototype = _write_graph(state.prototype, written, trial)
    next_state = replace(
        state,
        public_history=history,
        prototype=prototype,
        rng_state=pending.rng_state,
        p_hat=p_hat,
    )

    if isinstance(feedback, RevealedEdge):
        prototype = _write_relation(
            next_state.prototype,
            feedback.edge,
            trial,
        )
        return replace(
            next_state,
            public_history=(*next_state.public_history, feedback.edge),
            prototype=prototype,
            p_hat=update_frequency(next_state.p_hat, (feedback.edge,)),
        )
    if isinstance(feedback, CorrectnessBit) or feedback is None:
        return next_state
    raise TypeError("unknown feedback variant")


def redact(
    G_star: RelationGraph,
    held_out_edge: Relation,
    visibility_spec: Mapping[str, Any] | Iterable[str] | None,
) -> AgentInput:
    """完全 target graph から hold-out と不可視辺を除いた `AgentInput` を作る。

    `observable_mask` は公開済み relation_id の正の情報だけに限定し、完全グラフ上の
    bitmap や欠番 ID 列は返さない。
    """

    base_graph = _require_base_graph(visibility_spec)
    visible_relation_ids = _visible_relation_ids(G_star, held_out_edge, visibility_spec)
    visible_relations = tuple(
        relation for relation in G_star.relations if relation.relation_id in visible_relation_ids
    )
    visible_relations = _drop_relations_referencing_hidden(
        visible_relations,
        {held_out_edge.relation_id},
    )
    target_graph_partial = RelationGraph(
        graph_id=G_star.graph_id,
        entities=tuple(G_star.entities),
        relations=visible_relations,
    )
    return AgentInput(
        base_graph=base_graph,
        target_graph_partial=target_graph_partial,
        observable_mask=tuple(relation.relation_id for relation in visible_relations),
    )


def _visible_relation_ids(
    graph: RelationGraph,
    hidden_relation: Relation,
    visibility_spec: Mapping[str, Any] | Iterable[str] | None,
) -> set[str]:
    all_ids = {relation.relation_id for relation in graph.relations}
    if visibility_spec is None:
        visible_ids = set(all_ids)
    elif isinstance(visibility_spec, Mapping):
        raw_ids = visibility_spec.get("visible_relation_ids")
        if raw_ids is None:
            raw_ids = visibility_spec.get("observable_relation_ids")
        if raw_ids is None:
            raw_ids = all_ids
        visible_ids = {str(relation_id) for relation_id in raw_ids}
    else:
        visible_ids = {str(relation_id) for relation_id in visibility_spec}

    visible_ids.intersection_update(all_ids)
    visible_ids.discard(hidden_relation.relation_id)
    return visible_ids


def _drop_relations_referencing_hidden(
    relations: tuple[Relation, ...],
    hidden_ids: set[str],
) -> tuple[Relation, ...]:
    """不可視 relation_id を引数に持つ relation を推移的に可視集合から除く。"""

    hidden = set(hidden_ids)
    changed = True
    while changed:
        changed = False
        for relation in relations:
            if relation.relation_id in hidden:
                continue
            if any(argument in hidden for argument in relation.arguments):
                hidden.add(relation.relation_id)
                changed = True
    return tuple(relation for relation in relations if relation.relation_id not in hidden)


def _require_base_graph(
    visibility_spec: Mapping[str, Any] | Iterable[str] | None,
) -> RelationGraph:
    if not isinstance(visibility_spec, Mapping):
        raise TypeError("visibility_spec must be a mapping with base_graph")
    if "base_graph" not in visibility_spec:
        raise ValueError("visibility_spec must include base_graph")
    base_graph = visibility_spec["base_graph"]
    if not isinstance(base_graph, RelationGraph):
        raise TypeError("visibility_spec['base_graph'] must be a RelationGraph")
    return base_graph


def _append_relation(graph: RelationGraph, relation: Relation) -> RelationGraph:
    if any(existing.relation_id == relation.relation_id for existing in graph.relations):
        return graph
    return RelationGraph(
        graph_id=graph.graph_id,
        entities=tuple(graph.entities),
        relations=(*graph.relations, relation),
    )


def _write_graph(
    prototype: Prototype,
    observed: RelationGraph | None,
    trial: int,
) -> Prototype:
    if observed is None:
        return prototype
    return Prototype((*prototype.traces, VerbatimTrace(trial, observed)))


def _write_relation(
    prototype: Prototype,
    relation: Relation,
    trial: int,
) -> Prototype:
    traces = list(prototype.traces)
    if not traces or traces[-1].written_at != trial:
        traces.append(VerbatimTrace(trial, RelationGraph(f"scene-{trial}", relations=(relation,))))
    else:
        trace = traces[-1]
        traces[-1] = VerbatimTrace(trace.written_at, _append_relation(trace.scene, relation))
    return Prototype(tuple(traces))


def _snapshot_rng_state(
    rng: RNG,
    fallback: str | int | tuple[Any, ...] | None,
) -> str | int | tuple[Any, ...] | None:
    if isinstance(rng, Random):
        return rng.getstate()
    getstate = getattr(rng, "getstate", None)
    if callable(getstate):
        state = getstate()
        if isinstance(state, (str, int, tuple)) or state is None:
            return state
    return fallback
